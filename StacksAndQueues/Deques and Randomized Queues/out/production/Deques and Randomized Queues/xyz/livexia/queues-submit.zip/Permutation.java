//package xyz.livexia;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

public class Permutation {
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        In in = new In(args[2]);
        RandomizedQueue<String> rQ = new RandomizedQueue<String>();
        while(!in.isEmpty()){
            rQ.enqueue(in.readString());
        }
        for (int i=0;i<n;i++)
            StdOut.println(rQ.dequeue());
    }
}
